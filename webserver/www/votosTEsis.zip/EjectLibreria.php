<?php
 include("libreria.php");
$a=5;
$b=10;

$resultado=sumar($a,$b);



echo 'Suma es  :' .$resultado. '<br/>';


?>