<?php
 
function sumar($a,$b)
{

$suma=$a+$b;



return $suma;
}
?>