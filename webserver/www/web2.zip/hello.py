#!/usr/bin/env python
print "Content-Type: text/html"
print
print """\
<html>
<head><title>First Python HTTP Programming </title></head>
<body>
<h2>Hello World!</h2>
</body>
</html>
"""

