<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html><head>
<meta content="text/html; charset=ISO-8859-1" http-equiv="content-type"><title>index.html</title></head><body style="color: rgb(0, 0, 0); background-color: rgb(0, 153, 0);" alink="#000099" link="#000099" vlink="#990099">
<div style="text-align: center;"><big><big><big>Universidad Autonoma de Baja California</big></big></big><br>
</div>
<div style="text-align: center;"><br>
<img style="width: 73px; height: 106px;" alt="escudo" src="file:///home/alex/webpanda/escudo_uabc_gr1.jpg"><br>
<br>
<br>
<div style="text-align: left;"><big><big>Sistema de Monitoreo de Sensores.<br>
</big></big>&nbsp;&nbsp;&nbsp; <br>
<big style="color: rgb(0, 0, 1);"><big>&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; Menu</big></big>:<br>
<ul>
  <li><a href="mostrar.php">Ver estado de monitores.</a></li>
  <li>Ayuda.</li>
  <li>Mapa de los Sensores.</li>
  <li>Administrador.</li>
</ul>
<br>
<br>
<br>
</div>
</div>
</body></html>