<html xmlns:v="urn:schemas-microsoft-com:vml"
xmlns:o="urn:schemas-microsoft-com:office:office"
xmlns:dt="uuid:C2F41010-65B3-11d1-A29F-00AA00C14882"
xmlns="http://www.w3.org/TR/REC-html40">

<head>
<meta http-equiv=Content-Type content="text/html; charset=windows-1252">
<link rel=File-List href="mapa_archivos/filelist.xml">
<!--[if !mso]>
<style>
v\:* {behavior:url(#default#VML);}
o\:* {behavior:url(#default#VML);}
b\:* {behavior:url(#default#VML);}
.shape {behavior:url(#default#VML);}
</style>
<![endif]-->
<title>P�gina principal</title>
<style>
<!--
 /* Definiciones de fuente */
@font-face
	{font-family:"Times New Roman";
	panose-1:2 2 6 3 5 4 5 2 3 4;}
@font-face
	{font-family:"Arial Black";
	panose-1:2 11 10 4 2 1 2 2 2 4;}
@font-face
	{font-family:Arial;
	panose-1:2 11 6 4 2 2 2 2 2 4;}
 /* Definiciones de estilo */
p.MsoNormal, li.MsoNormal, div.MsoNormal
	{margin-right:0pt;
	text-indent:0pt;
	margin-top:0pt;
	margin-bottom:0pt;
	text-align:left;
	font-family:"Times New Roman";
	font-size:10.0pt;
	color:black;}
ol
	{margin-top:0in;
	margin-bottom:0in;
	margin-left:-2197in;}
ul
	{margin-top:0in;
	margin-bottom:0in;
	margin-left:-2197in;}
@page
	{size:8.-2019in 11.2232in;}
-->
</style>
<!--[if gte mso 9]><xml>
 <o:shapedefaults v:ext="edit" spidmax="5122" fill="f" fillcolor="white [7]"
  strokecolor="black [0]">
  <v:fill color="white [7]" color2="white [7]" on="f"/>
  <v:stroke color="black [0]" color2="white [7]">
   <o:left v:ext="view" color="black [0]" color2="white [7]"/>
   <o:top v:ext="view" color="black [0]" color2="white [7]"/>
   <o:right v:ext="view" color="black [0]" color2="white [7]"/>
   <o:bottom v:ext="view" color="black [0]" color2="white [7]"/>
   <o:column v:ext="view" color="black [0]" color2="white [7]"/>
  </v:stroke>
  <v:shadow color="#ccc [4]"/>
  <v:textbox inset="2.88pt,2.88pt,2.88pt,2.88pt"/>
  <o:colormru v:ext="edit" colors="#3c3"/>
  <o:colormenu v:ext="edit" fillcolor="#306 [1]" strokecolor="black [0]"
   shadowcolor="#ccc [4]"/>
 </o:shapedefaults><o:shapelayout v:ext="edit">
  <o:idmap v:ext="edit" data="1"/>
 </o:shapelayout></xml><![endif]-->
</head>

<body link="#6633CC" vlink=blue bgcolor="#33CC33" style='margin:0'>

<div style='position:absolute;width:7.-71in;height:9.0242in'>
<!--[if gte vml 1]><v:rect id="_x0000_s1050" alt="" style='position:absolute;
 left:.18pt;top:59.25pt;width:6.91pt;height:594pt;z-index:5;visibility:visible;
 mso-wrap-edited:f;mso-wrap-distance-left:2.88pt;mso-wrap-distance-top:2.88pt;
 mso-wrap-distance-right:2.88pt;mso-wrap-distance-bottom:2.88pt;
 mso-position-horizontal:absolute;mso-position-horizontal-relative:text;
 mso-position-vertical:absolute;mso-position-vertical-relative:text'
 fillcolor="#699 [3]" stroked="f" strokecolor="black [0]" o:cliptowrap="t">
 <v:stroke color2="white [7]">
  <o:left v:ext="view" color="black [0]" color2="white [7]"/>
  <o:top v:ext="view" color="black [0]" color2="white [7]"/>
  <o:right v:ext="view" color="black [0]" color2="white [7]"/>
  <o:bottom v:ext="view" color="black [0]" color2="white [7]"/>
  <o:column v:ext="view" color="black [0]" color2="white [7]"/>
 </v:stroke>
 <v:shadow color="#ccc [4]"/>
 <v:path insetpenok="f"/>
 <o:lock v:ext="edit" shapetype="t"/>
 <v:textbox style='mso-column-margin:2.85pt' inset="2.88pt,2.88pt,2.88pt,2.88pt">
  <div dir=ltr></div>
 </v:textbox>
</v:rect><![endif]--><![if !vml]><span style='position:absolute;z-index:5;
left:0px;top:79px;width:10px;height:793px'><img width=10 height=793
src="mapa_archivos/image338.gif" v:shapes="_x0000_s1050"></span><![endif]><!--[if gte vml 1]><v:rect
 id="_x0000_s1088" style='position:absolute;left:246pt;top:63pt;width:49.95pt;
 height:1in;z-index:6;mso-wrap-distance-left:2.88pt;mso-wrap-distance-top:2.88pt;
 mso-wrap-distance-right:2.88pt;mso-wrap-distance-bottom:2.88pt'
 o:preferrelative="t" filled="f" fillcolor="white [7]" stroked="f"
 strokecolor="black [0]" o:cliptowrap="t">
 <v:fill color2="white [7]"/>
 <v:stroke color2="white [7]">
  <o:left v:ext="view" color="black [0]" color2="white [7]"/>
  <o:top v:ext="view" color="black [0]" color2="white [7]"/>
  <o:right v:ext="view" color="black [0]" color2="white [7]"/>
  <o:bottom v:ext="view" color="black [0]" color2="white [7]"/>
  <o:column v:ext="view" color="black [0]" color2="white [7]"/>
 </v:stroke>
 <v:imagedata src="mapa_archivos/image344.jpg" o:title="escudo_uabc_gr1"/>
 <v:shadow color="#ccc [4]"/>
 <v:path o:extrusionok="f" insetpenok="f"/>
 <o:lock v:ext="edit" aspectratio="t"/>
</v:rect><![endif]--><![if !vml]><span style='position:absolute;z-index:6;
left:328px;top:84px;width:67px;height:96px'><img width=67 height=96
src="mapa_archivos/image344.jpg" v:shapes="_x0000_s1088"></span><![endif]><!--[if gte vml 1]><v:shapetype
 id="_x0000_t202" coordsize="21600,21600" o:spt="202" path="m,l,21600r21600,l21600,xe">
 <v:stroke joinstyle="miter"/>
 <v:path gradientshapeok="t" o:connecttype="rect"/>
</v:shapetype><v:shape id="_x0000_s1089" type="#_x0000_t202" style='position:absolute;
 left:12pt;top:15pt;width:534pt;height:30pt;z-index:7;mso-wrap-distance-left:2.88pt;
 mso-wrap-distance-top:2.88pt;mso-wrap-distance-right:2.88pt;
 mso-wrap-distance-bottom:2.88pt' filled="f" fillcolor="white [7]" stroked="f"
 strokecolor="black [0]" o:cliptowrap="t">
 <v:fill color2="white [7]"/>
 <v:stroke color2="white [7]">
  <o:left v:ext="view" color="black [0]" color2="white [7]"/>
  <o:top v:ext="view" color="black [0]" color2="white [7]"/>
  <o:right v:ext="view" color="black [0]" color2="white [7]"/>
  <o:bottom v:ext="view" color="black [0]" color2="white [7]"/>
  <o:column v:ext="view" color="black [0]" color2="white [7]"/>
 </v:stroke>
 <v:shadow color="#ccc [4]"/>
 <v:path insetpenok="f"/>
 <v:textbox style='mso-column-margin:2mm' inset="2.88pt,2.88pt,2.88pt,2.88pt"/>
</v:shape><![endif]--><![if !vml]><span style='position:absolute;z-index:7;
left:16px;top:20px;width:712px;height:40px'>

<table cellpadding=0 cellspacing=0>
 <tr>
  <td width=712 height=40 style='vertical-align:top'><![endif]>
  <div v:shape="_x0000_s1089" style='padding:2.88pt 2.88pt 2.88pt 2.88pt'
  class=shape>
  <p class=MsoNormal style='text-align:center;text-align:center'><span
  lang=en-US style='font-size:22.0pt;font-family:"Arial Black";language:en-US'>Universida Autonoma de Baja California.</span></p>
  </div>
  <![if !vml]></td>
 </tr>
</table>

</span><![endif]><!--[if gte vml 1]><v:shape id="_x0000_s1090" type="#_x0000_t202"
 style='position:absolute;left:177pt;top:138pt;width:195pt;height:39pt;
 z-index:8;mso-wrap-distance-left:2.88pt;mso-wrap-distance-top:2.88pt;
 mso-wrap-distance-right:2.88pt;mso-wrap-distance-bottom:2.88pt' filled="f"
 fillcolor="white [7]" stroked="f" strokecolor="black [0]" o:cliptowrap="t">
 <v:fill color2="white [7]"/>
 <v:stroke color2="white [7]">
  <o:left v:ext="view" color="black [0]" color2="white [7]"/>
  <o:top v:ext="view" color="black [0]" color2="white [7]"/>
  <o:right v:ext="view" color="black [0]" color2="white [7]"/>
  <o:bottom v:ext="view" color="black [0]" color2="white [7]"/>
  <o:column v:ext="view" color="black [0]" color2="white [7]"/>
 </v:stroke>
 <v:shadow color="#ccc [4]"/>
 <v:path insetpenok="f"/>
 <v:textbox style='mso-column-margin:2mm' inset="2.88pt,2.88pt,2.88pt,2.88pt"/>
</v:shape><![endif]--><![if !vml]><span style='position:absolute;z-index:8;
left:236px;top:184px;width:260px;height:52px'>

<table cellpadding=0 cellspacing=0>
 <tr>
  <td width=260 height=52 style='vertical-align:top'><![endif]>
  <div v:shape="_x0000_s1090" style='padding:2.88pt 2.88pt 2.88pt 2.88pt'
  class=shape>
  <p class=MsoNormal style='text-align:center;text-align:center'><span
  lang=en-US style='font-size:15.0pt;font-weight:bold;language:en-US'>Mapa de los Nodos</span></p>
  </div>
  <![if !vml]></td>
 </tr>
</table>

</span><![endif]><!--[if gte vml 1]><v:rect id="_x0000_s1130" style='position:absolute;
 left:33pt;top:249pt;width:341.54pt;height:353.9pt;z-index:9;
 mso-wrap-distance-left:2.88pt;mso-wrap-distance-top:2.88pt;
 mso-wrap-distance-right:2.88pt;mso-wrap-distance-bottom:2.88pt'
 o:preferrelative="t" filled="f" fillcolor="white [7]" stroked="f"
 strokecolor="black [0]" o:cliptowrap="t">
 <v:fill color2="white [7]"/>
 <v:stroke color2="white [7]">
  <o:left v:ext="view" color="black [0]" color2="white [7]"/>
  <o:top v:ext="view" color="black [0]" color2="white [7]"/>
  <o:right v:ext="view" color="black [0]" color2="white [7]"/>
  <o:bottom v:ext="view" color="black [0]" color2="white [7]"/>
  <o:column v:ext="view" color="black [0]" color2="white [7]"/>
 </v:stroke>
 <v:imagedata src="mapa_archivos/image361.jpg" o:title="mapa"/>
 <v:shadow color="#ccc [4]"/>
 <v:path o:extrusionok="f" insetpenok="f"/>
 <o:lock v:ext="edit" aspectratio="t"/>
</v:rect><![endif]--><![if !vml]><span style='position:absolute;z-index:9;
left:44px;top:332px;width:455px;height:472px'><img width=455 height=472
src="mapa_archivos/image361.jpg" v:shapes="_x0000_s1130"></span><![endif]><!--[if gte vml 1]><v:shape
 id="_x0000_s1131" type="#_x0000_t202" style='position:absolute;left:387pt;
 top:231pt;width:147pt;height:483pt;z-index:10;mso-wrap-distance-left:2.88pt;
 mso-wrap-distance-top:2.88pt;mso-wrap-distance-right:2.88pt;
 mso-wrap-distance-bottom:2.88pt' filled="f" fillcolor="white [7]"
 strokecolor="black [0]" strokeweight="4.5pt" o:cliptowrap="t">
 <v:fill color2="white [7]"/>
 <v:stroke color2="white [7]" linestyle="thickThin">
  <o:left v:ext="view" color="black [0]" color2="white [7]" joinstyle="miter"/>
  <o:top v:ext="view" color="black [0]" color2="white [7]" joinstyle="miter"/>
  <o:right v:ext="view" color="black [0]" color2="white [7]" joinstyle="miter"/>
  <o:bottom v:ext="view" color="black [0]" color2="white [7]" joinstyle="miter"/>
  <o:column v:ext="view" color="black [0]" color2="white [7]"/>
 </v:stroke>
 <v:shadow color="#ccc [4]"/>
 <v:path insetpenok="f"/>
 <v:textbox style='mso-column-margin:2mm' inset="2.88pt,2.88pt,2.88pt,2.88pt">
  <div dir=ltr>
  <p class=MsoNormal><span lang=en-US style='font-family:Arial;font-weight:
  bold;language:en-US'>Ver Ubicaciones:</span></p>
  <p class=MsoNormal><span lang=en-US style='font-family:Arial;font-weight:
  bold;language:en-US'>&nbsp;</span></p>
  <p class=MsoNormal><span lang=en-US style='font-family:Arial;font-weight:
  bold;language:en-US'>Ubicacion�������� Estado</span></p>
  <p class=MsoNormal><span lang=en-US style='font-weight:bold;language:en-US'>&nbsp;</span></p>
  <p class=MsoNormal><span lang=en-US style='font-weight:bold;language:en-US'>1�������������� ���������������� :</span></p>
  <p class=MsoNormal><span lang=en-US style='font-weight:bold;language:en-US'>&nbsp;</span></p>
  <p class=MsoNormal><span lang=en-US style='font-weight:bold;language:en-US'>2�������������� ���������������� :</span></p>
  <p class=MsoNormal><span lang=en-US style='font-weight:bold;language:en-US'>&nbsp;</span></p>
  <p class=MsoNormal><span lang=en-US style='font-weight:bold;language:en-US'>3�������������� ���������������� :��������������� </span></p>
  <p class=MsoNormal><span lang=en-US style='font-weight:bold;language:en-US'>&nbsp;</span></p>
  <p class=MsoNormal><span lang=en-US style='font-weight:bold;language:en-US'>4�������������� ���������������� :��������������� </span></p>
  <p class=MsoNormal><span lang=en-US style='font-weight:bold;language:en-US'>&nbsp;</span></p>
  <p class=MsoNormal><span lang=en-US style='font-weight:bold;language:en-US'>5�������������� ���������������� :</span></p>
  <p class=MsoNormal><span lang=en-US style='font-weight:bold;language:en-US'>&nbsp;</span></p>
  <p class=MsoNormal><span lang=en-US style='font-weight:bold;language:en-US'>6�������������� ���������������� :</span></p>
  <p class=MsoNormal><span lang=en-US style='font-weight:bold;language:en-US'>&nbsp;</span></p>
  <p class=MsoNormal><span lang=en-US style='font-weight:bold;language:en-US'>7�������������� ���������������� :</span></p>
  <p class=MsoNormal><span lang=en-US style='font-weight:bold;language:en-US'>&nbsp;</span></p>
  <p class=MsoNormal><span lang=en-US style='font-weight:bold;language:en-US'>8�������������� ���������������� :</span></p>
  <p class=MsoNormal><span lang=en-US style='font-weight:bold;language:en-US'>&nbsp;</span></p>
  <p class=MsoNormal><span lang=en-US style='font-weight:bold;language:en-US'>9�������������� ���������������� :</span></p>
  <p class=MsoNormal><span lang=en-US style='font-weight:bold;language:en-US'>&nbsp;</span></p>
  <p class=MsoNormal><span lang=en-US style='font-weight:bold;language:en-US'>10������������ ���������������� :</span></p>
  <p class=MsoNormal><span lang=en-US style='font-weight:bold;language:en-US'>&nbsp;</span></p>
  <p class=MsoNormal><span lang=en-US style='font-weight:bold;language:en-US'>11������������ ���������������� :</span></p>
  <p class=MsoNormal><span lang=en-US style='font-weight:bold;language:en-US'>&nbsp;</span></p>
  <p class=MsoNormal><span lang=en-US style='font-weight:bold;language:en-US'>12������������ ���������������� :</span></p>
  <p class=MsoNormal><span lang=en-US style='font-weight:bold;language:en-US'>&nbsp;</span></p>
  <p class=MsoNormal><span lang=en-US style='font-weight:bold;language:en-US'>13������������ ���������������� :</span></p>
  <p class=MsoNormal><span lang=en-US style='font-weight:bold;language:en-US'>&nbsp;</span></p>
  <p class=MsoNormal><span lang=en-US style='font-weight:bold;language:en-US'>14������������ ���������������� :</span></p>
  <p class=MsoNormal><span lang=en-US style='font-weight:bold;language:en-US'>&nbsp;</span></p>
  <p class=MsoNormal><span lang=en-US style='font-weight:bold;language:en-US'>15������������ ���������������� :</span></p>
  <p class=MsoNormal><span lang=en-US style='font-weight:bold;language:en-US'>&nbsp;</span></p>
  <p class=MsoNormal><span lang=en-US style='font-weight:bold;language:en-US'>16������������ ���������������� :</span></p>
  <p class=MsoNormal><span lang=en-US style='language:en-US'>&nbsp;</span></p>
  </div>
 </v:textbox>
</v:shape><![endif]--><![if !vml]><span style='position:absolute;z-index:10;
left:513px;top:305px;width:202px;height:650px'><img width=202 height=650
src="mapa_archivos/image364.gif"
alt="Cuadro de texto: Ver Ubicaciones:&#13;&#13;Ubicacion	Estado&#13;&#13;1		:&#13;&#13;2		:&#13;&#13;3		:	&#13;&#13;4		:	&#13;&#13;5		:&#13;&#13;6		:&#13;&#13;7		:&#13;&#13;8		:&#13;&#13;9		:&#13;&#13;10		:&#13;&#13;11		:&#13;&#13;12		:&#13;&#13;13		:&#13;&#13;14		:&#13;&#13;15		:&#13;&#13;16		:&#13;&#13;"
v:shapes="_x0000_s1131"></span><![endif]>
</div>

</body>

</html>
